# 1. Startup

- Startup an HTTP server.
- Respond to all requests with "Hello world"
- Use Postman or similar to make a request.

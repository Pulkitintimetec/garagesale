// Package user implements all business logic regarding users.
package user
